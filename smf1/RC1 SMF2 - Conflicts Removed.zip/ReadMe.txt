/**********************************************************************************
* ReadMe.php                                                                      *
***********************************************************************************
* SMF Garage: Simple Machines Forum Garage (MOD)                                  *
* =============================================================================== *
* Software Version:           SMF Garage 1.0 RC1                                  *
* Install for:                2.0-2.99                                            *
* Software by:                RRasco (http://www.smfgarage.com)                   *
* Copyright 2007-2009 by:     SMF Garage (http://www.smfgarage.com)               *
*                             RRasco (rrasco@smfgarage.com)                       *
* Templates by:               Esmond Poynton (esmond.poynton@gmail.com)           *
* Support, News, Updates at:  http://www.smfgarage.com                            *
***********************************************************************************
* This program is free software: you can redistribute it and/or modify            *
* it under the terms of the GNU General Public License as published by            *
* the Free Software Foundation, either version 3 of the License, or               *
* (at your option) any later version.                                             *
*                                                                                 *
* This program is distributed in the hope that it will be useful,                 *
* but WITHOUT ANY WARRANTY; without even the implied warranty of                  *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                   *
* GNU General Public License for more details.                                    *
*                                                                                 *
* You should have received a copy of the GNU General Public License               *
* along with this program.  If not, see <http://www.gnu.org/licenses/>.           *
*                                                                                 *
* See the "SMF_Garage_License.txt" file for details.                              *
*              http://opensource.org/licenses/gpl-3.0.html                        *
*                                                                                 *
* The latest version can always be found at:                                      *
*              http://www.smfgarage.com                                           *
*              http://www.simplemachines.org                                      *
**********************************************************************************/
*
* Development Team:
*
* RRasco (rrasco@smfgarage.com)
*     http://www.smfgarage.com
*
* Snowcone (SBGamesCone@gmail.com)
*     http://www.snackbar-games.com
*
* Quake101 (quake101@smfgarage.com)
*     http://www.badassmustangs.com
*
* TheSin (thesin@smfgarage.com)
*     http://www.na4wda.org
*
**********************************************************************************
*
* Description:
*
* SMF Garage is a CMS extension for SMF which allows each user
* to add a configurable number of vehicles; otherwise, it attaches
* a vehicle profile to user accounts.  Each vehicle profile is
* able to attach vehicle details, images, modifications, dynoruns,
* quartermile runs, insurance premiums, lap times, shop reviews, 
* and garage reviews.  The garage is completely configurable by
* the administrator with its own permissions system built in.
* 
* SMF Garage is a port from phpBB Garage (http://www.phpbbgarage.com)
* which will be equipped with converters to move from SMF > phpBB or
* phpBB > SMF.
* 
* For more information or support regarding SMF Garage, please 
* visit (http://www.smfgarage.com).
* 
**********************************************************************************
*
* Thanks!
*
* I would first like to thank the SMF Development Team for putting
* together IMO the best open source forum software available today.
* Their continued efforts have provided us with an exceptional piece
* of software to work with.  Once again, thanks Team SMF!
*
* Next, I'd like to thank the SMF Garage development team: Snowcone, 
* Quake101, and TheSin.  Without the dedication and willingness of 
* you guys we would not have come together to create one the of the most
* functional and biggest SMF mods to date.  Also, I'd like to thank 
* Poyntesm for helping me port this over from his phpBB Garage.
*
* And to all you various SMFers that constantly answered my questions 
* at SMF.org...cheers to you mates!
*
* Thanks again team, without any of you, SMF Garage would not be.
*
**********************************************************************************